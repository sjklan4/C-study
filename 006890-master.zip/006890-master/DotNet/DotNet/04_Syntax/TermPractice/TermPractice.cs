﻿using System;

class TermPractice
{
    static void Main()
    {
        Console.WriteLine("System 네임스페이스");
        Console.WriteLine("Console 클래스");
        Console.WriteLine("WriteLine 메서드");
    }
}
