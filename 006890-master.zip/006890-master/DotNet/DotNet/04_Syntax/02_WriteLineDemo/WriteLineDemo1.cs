﻿class WriteLineDemo1
{
    static void Main()
    {
        System.Console.WriteLine("명령 프롬프트에 출력할 내용");        
    }
}
