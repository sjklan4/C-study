﻿class IndentTab
{
    static void Main()
    {
        System.Console.WriteLine("탭 키 대신에 공백 4칸 사용");
            System.Console.WriteLine("들여쓰기로 코드의 시작과 끝을 명확히");
    }
}
