﻿using System;

class Indent
{
    static void Main()
    {
        Console.WriteLine("들여쓰기는 공백 4칸을 사용");
    }
}

