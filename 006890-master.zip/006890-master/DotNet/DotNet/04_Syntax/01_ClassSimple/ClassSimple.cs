﻿using System;

class ClassSimple
{
    static void Main()
    {
        Console.WriteLine("Hello, World!");
    }
}
