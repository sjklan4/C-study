﻿using System;

class Comment
{
    static void Main()
    {
        // 주석문은 실행에 영향을 주지 않는 코드 설명문입니다.
        Console.WriteLine("주석문");
    }
}
