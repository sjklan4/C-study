﻿using System;

class SingleLineComment
{
    static void Main()
    {
        //Console.WriteLine("현재 구문은 실행되지 않습니다.");
    }
}
