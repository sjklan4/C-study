﻿using System;

class ConsoleWrite
{
    static void Main()
    {
        Console.Write("줄바꿈 없음");
        Console.WriteLine("줄바꿈 포함");
    }
}
