﻿using System;

class FormatPractice
{
    static void Main()
    {
        Console.WriteLine("{0}", "Hello, World");
    }
}
