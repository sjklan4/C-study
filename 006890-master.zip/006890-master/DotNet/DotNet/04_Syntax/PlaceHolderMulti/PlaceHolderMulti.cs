﻿using System;

class PlaceHolderMulti
{
    static void Main()
    {
        Console.WriteLine("{0}, {1}", "Hello", "C#");
    }
}
