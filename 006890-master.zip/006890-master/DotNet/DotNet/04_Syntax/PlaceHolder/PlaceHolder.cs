﻿using System;

class PlaceHolder
{
    static void Main()
    {
        Console.WriteLine("{0}", "Hello, C#");
    }
}
