﻿using System;

class PlaceHolderTwice
{
    static void Main()
    {
        Console.WriteLine("{0}", "Hello, C#");
        Console.WriteLine("{0}, {0}", "Hello, C#");
    }
}
