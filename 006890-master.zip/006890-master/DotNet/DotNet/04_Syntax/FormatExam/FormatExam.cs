﻿using System;

class FormatExam
{
    static void Main()
    {
        Console.WriteLine("{0}, {1}", "Hello", "C#");
    }
}
