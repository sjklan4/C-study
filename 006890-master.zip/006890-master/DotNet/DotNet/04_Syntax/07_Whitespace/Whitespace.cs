﻿// 공백(Whitespace): 프로그래밍 언어에서 공백은 무시된다. 
using System;

class Whitespace
{
    static void Main(string[] args)
    {
        Console.WriteLine("C#");
        Console.  WriteLine  (  "C#"  )  ;
        Console
            .WriteLine(
                "C#")
        ;
    }
}
