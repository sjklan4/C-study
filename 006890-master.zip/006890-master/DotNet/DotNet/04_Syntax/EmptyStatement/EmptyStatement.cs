﻿using System;

class EmptyStatement
{
    static void Main()
    {
        ;
        ;
        ;
    }
}
