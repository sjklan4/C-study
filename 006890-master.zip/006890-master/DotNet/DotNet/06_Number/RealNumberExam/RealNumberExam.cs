﻿using System;

class RealNumberExam
{
    static void Main()
    {
        float   f = 3.14f;
        double  d = 12.34d;
        decimal m = 99.99m;

        Console.WriteLine("{0}, {1}, {2}", f, d, m);
    }
}
