﻿// 연습문제: 실수형 변수 선언하기
using System;

class RealNumberPractice
{
    static void Main()
    {
        float   f = 3.14F;
        double  d = 3.14D;
        decimal m = 3.14M;

        Console.WriteLine("{0}, {1}, {2}", f, d, m);
    }
}
