﻿// decimal 키워드: 실수형 데이터 형식(128비트 10진수)
using System;

class DecimalDemo
{
    static void Main()
    {
        decimal d = 12.34M; // decimal 변수 선언 후 실수 데이터 저장 
        Console.WriteLine("{0}", d); // 12.34
    }
}
