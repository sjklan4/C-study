﻿// double 키워드: 실수형 데이터 형식(64비트 부동 소수점 숫자)
using System;

class DoubleDemo
{
    static void Main()
    {
        double PI = 3.141592; // 배정밀도 부동 소수점 변수를 선언하고 값을 할당
        Console.WriteLine("{0}", PI); // 3.141592
    }
}
