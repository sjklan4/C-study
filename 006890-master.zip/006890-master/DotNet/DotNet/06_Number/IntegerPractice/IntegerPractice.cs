﻿using System;

class IntegerPractice
{
    static void Main()
    {
        //[1] int 자료형의 최솟값
        Console.WriteLine("{0}", int.MinValue);
        //[2] int 자료형의 최댓값
        Console.WriteLine("{0}", int.MaxValue);
    }
}
