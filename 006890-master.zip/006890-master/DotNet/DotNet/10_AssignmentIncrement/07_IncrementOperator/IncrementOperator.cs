﻿//[?] 증가 연산자: 정수 자료형 변수의 값을 1 증가
using System;

class IncrementOperator
{
    static void Main()
    {
        int num = 100;
        ++num; // 1 증가
        Console.WriteLine(num); // 101
    }
}
