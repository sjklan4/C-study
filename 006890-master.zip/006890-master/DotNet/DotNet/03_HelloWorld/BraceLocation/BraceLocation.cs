﻿class BraceLocation
{
    static void Main()
    {

    }
}

//class BraceLocation {
//    static void Main() {

//    }
//}
