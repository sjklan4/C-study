﻿using System;

class HelloWorldPractice
{
    static void Main()
    {
        Console.WriteLine("Hello, World");
        Console.WriteLine("1234567890");
    }
}
