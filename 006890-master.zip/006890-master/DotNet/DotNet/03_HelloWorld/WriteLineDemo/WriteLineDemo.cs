﻿using static System.Console;

class WriteLineDemo
{
    static void Main()
    {
        WriteLine("명령 프롬프트에 출력할 내용");        
    }
}
