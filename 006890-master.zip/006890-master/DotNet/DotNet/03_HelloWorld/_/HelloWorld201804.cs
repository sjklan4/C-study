﻿using System;

class HelloWorld201804
{
    static void Main()
    {
        Console.WriteLine("C#");
        Console.WriteLine("Start");
    }
}
