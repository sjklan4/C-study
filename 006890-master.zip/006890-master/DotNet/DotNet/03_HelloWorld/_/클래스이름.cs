﻿using System;

class 클래스이름
{
    static void Main()
    {
        Console.WriteLine("Hello, World!");
    }
    static void Main(string[] args)
    {

    }
}
