﻿//class 중괄호위치
//{
//    static void Main()
//    {

//    }
//}

//class 중괄호위치 {
//    static void Main() {

//    }
//}
