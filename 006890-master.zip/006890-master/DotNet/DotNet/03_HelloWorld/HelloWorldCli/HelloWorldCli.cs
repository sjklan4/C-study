﻿using System;

namespace HelloWorldCli
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World! with Visual Studio Code");
        }
    }
}
