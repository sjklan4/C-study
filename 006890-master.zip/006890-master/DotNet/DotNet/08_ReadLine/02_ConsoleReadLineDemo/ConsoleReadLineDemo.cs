﻿using System;

class ConsoleReadLineDemo
{
    static void Main()
    {
        //[1] 콘솔로 입력받은 문자열을 그대로 콘솔에 출력하기 
        Console.WriteLine(Console.ReadLine());
    }
}
