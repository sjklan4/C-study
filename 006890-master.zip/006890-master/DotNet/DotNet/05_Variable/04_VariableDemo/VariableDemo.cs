﻿using System;

class VariableDemo
{
    static void Main()
    {
        int number = 7; //[1] 변수 선언과 동시에 초기화 
        Console.WriteLine("{0}", number);
    }
}
