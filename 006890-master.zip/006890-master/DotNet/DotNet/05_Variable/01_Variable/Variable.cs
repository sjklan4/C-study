﻿using System;

class Variable
{
    static void Main()
    {
        int number; //[1] 정수형 변수 선언하기
        number = 7; //[2] 변수에 값 대입(할당)하기 
        Console.WriteLine(number); //[3] 변수의 값을 화면에 출력하기 
    }
}
