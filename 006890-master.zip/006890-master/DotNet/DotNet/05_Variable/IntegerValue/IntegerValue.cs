﻿using System;

class IntegerValue
{
    static void Main()
    {
        //int number = 3.14; // 에러 발생
        int number = 3; // 정상 실행
        Console.WriteLine(number);
    }
}
