using System;

class VariablePractice
{
    static void Main()
    {
        // 여러 개의 변수를 선언과 동시에 초기화
        int first = 10, second = 20, third = 30;

        Console.WriteLine("{0}, {1}, {2}", first, second, third);
    }
}
