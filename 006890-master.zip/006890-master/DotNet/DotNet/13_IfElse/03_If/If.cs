﻿using System;

class If
{
    static void Main()
    {
        int score = 60;

        // score가 60 이상이면 "합격" 출력
        if (score >= 60)
        {
            Console.WriteLine("합격");
        }
    }
}
