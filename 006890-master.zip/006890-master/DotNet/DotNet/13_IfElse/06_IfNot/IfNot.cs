﻿using System;

class IfNot
{
    static void Main()
    {
        bool bln = false;
        if (!bln)
        {
            Console.WriteLine("bln: false -> ! -> true");
        }
    }
}
