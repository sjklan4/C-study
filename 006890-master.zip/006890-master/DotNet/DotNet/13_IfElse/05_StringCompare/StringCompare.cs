﻿using System;

class StringCompare
{
    static void Main()
    {
        string s1 = "Hello.";
        string s2 = "Hello.";

        if (s1 == s2) // s1과 s2가 같으면 true
        {
            Console.WriteLine("Same.");
        }
    }
}
