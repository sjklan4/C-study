﻿using System;

class ElsePractice
{
    static void Main()
    {
        bool bln = false;

        if (bln)
        {
            Console.WriteLine("참");     // bln == true
        }
        else
        {
            Console.WriteLine("거짓");    // bln == flase
        }
    }
}
