﻿using System;

class IfPractice
{
    static void Main()
    {
        int number = -1234;
        if (number < 0)
        {
            Console.WriteLine($"{number}은(는) 음수입니다.");
        }
    }
}
