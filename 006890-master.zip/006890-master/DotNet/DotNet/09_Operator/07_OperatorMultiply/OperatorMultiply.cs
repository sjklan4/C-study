﻿//[?] 곱하기(*) 연산자
using System;

class OperatorMultiply
{
    static void Main()
    {
        long i = 100;
        long j = 200;
        long k = i * j; // k = 100 * 200
        Console.WriteLine(k); // 20000
    }
}
