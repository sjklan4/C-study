﻿//[?] 나머지(%) 연산자
using System;

class OperatorRemainder
{
    static void Main()
    {
        int i = 5;
        int j = 3;
        int k = i % j; // k = 5 % 3
        Console.WriteLine(k); // 2
    }
}
