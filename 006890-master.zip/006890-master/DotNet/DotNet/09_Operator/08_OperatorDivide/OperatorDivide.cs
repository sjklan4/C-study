﻿//[?] 나누기(/) 연산자
using System;

class OperatorDivide
{
    static void Main()
    {
        double i = 1.5;
        double j = 0.5;
        double k = i / j; // k = 1.5 / 0.5
        Console.WriteLine(k); // 3
    }
}
