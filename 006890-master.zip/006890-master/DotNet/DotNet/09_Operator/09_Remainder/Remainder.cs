﻿//[?] 나머지 연산자(Remainder Operator): 몫이 아닌 나머지 값 구하기
using System;

class Remainder
{
    static void Main()
    {
        int first = 5;
        int second = 3;
        int result = 0;
        result = first % second; 
        Console.WriteLine(result); // 몫: 1, 나머지: {2}
    }
}
