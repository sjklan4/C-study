﻿//[?] 더하기(+) 연산자
using System;

class OperatorAdd
{
    static void Main()
    {
        int i = 10;
        int j = 20;
        int k = i + j; // k = 10 + 20
        Console.WriteLine(k); // 30
    }
}
