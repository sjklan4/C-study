﻿using System;

class OperatorQuiz
{
    static void Main()
    {
        int number1 = 10;
        int number2 = 20;
        int number3;

        number3 = number1 + number2;
        number3 = 10 + 20;
        number3 = number1 + 10;
        number3 = +number2;
    }
}
