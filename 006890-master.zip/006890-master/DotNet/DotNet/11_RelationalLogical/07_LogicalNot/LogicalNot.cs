﻿// 논리 연산자: ! -> 논리 NOT: 참이면 거짓, 거짓이면 참으로 변환
using System;

class LogicalNot
{
    static void Main()
    {
        // ! 연산자: NOT
        Console.WriteLine($"!true  -> {!true}  "); // false
        Console.WriteLine($"!false -> {!false} "); // true
    }
}
