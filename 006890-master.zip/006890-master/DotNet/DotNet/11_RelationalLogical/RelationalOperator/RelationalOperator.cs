﻿using System;

class RelationalOperator
{
    static void Main()
    {
        // 3이 5보다 작은지?
        Console.WriteLine(3 < 5); // True
        // 3이 5보다 큰지? 
        Console.WriteLine(3 > 5); // False
    }
}
