﻿class BinaryLiteralNote
{
    static void Main()
    {
        // 0b 접두사를 붙이고 이진수를 4자리 단위로 표시 가능
        int[] numbers = { 0b1, 0b10, 0b100, 0b1000, 0b1_0000, 0b10_0000 };
    }
}
