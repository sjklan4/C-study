﻿using System;

class ArrayLanguages
{
    static void Main()
    {
        string[] languages = { "Korean", "English", "Spanish" };
        Console.WriteLine($"{languages[0]}, {languages[1]}, {languages[2]}");
    }
}
