﻿using System;

class TernaryQuiz
{
    static void Main()
    {
        int one = 1;
        int two = 2;

        two = (one > 1) ? 1111 : 2222;

        Console.WriteLine(two);
    }
}
