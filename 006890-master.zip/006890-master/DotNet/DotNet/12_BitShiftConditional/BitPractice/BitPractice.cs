﻿using System;

class BitPractice
{
    static void Main()
    {
        Console.WriteLine(5 & 3);
        Console.WriteLine(5 | 3);
        Console.WriteLine(5 ^ 3);
    }
}
