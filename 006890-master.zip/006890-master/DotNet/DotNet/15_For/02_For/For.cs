﻿using System;

class For
{
    static void Main()
    {
        // 1부터 5까지 1씩 증가 => 5번 반복
        for (int i = 1; i <= 5; i++)
        {
            Console.WriteLine("Count: {0}", i);
        }
    }
}
