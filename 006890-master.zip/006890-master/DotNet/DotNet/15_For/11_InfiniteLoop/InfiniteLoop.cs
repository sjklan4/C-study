﻿using System;

class InfiniteLoop
{
    static void Main()
    {
        // 무한 루프
        for ( ; ; )
        {
            Console.WriteLine("무한 루프");
        }
    }
}
