﻿using System;

class LiteralPractice
{
    static void Main()
    {
        char c = '가';
        string s = "HELLO";
        float f = 3.14F; 
        Console.WriteLine("{0} {1} {2}", c, s, f);
    }
}
