﻿using System;

class MultiLineString
{
    static void Main()
    {
        string multiLines = @"
            안녕하세요.
            반갑습니다. 
        ";

        Console.WriteLine(multiLines);
    }
}
