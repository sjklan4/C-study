﻿// char 키워드: 문자 데이터 형식 변수를 선언
using System;

class CharacterDemo
{
    static void Main()
    {
        char grade = 'A';
        char kor = '가';

        Console.WriteLine(grade);
        Console.WriteLine(kor);
    }
}
