﻿using System;

class CharacterExam
{
    static void Main()
    {
        char ch;
        
        ch = '\t';

        Console.WriteLine("Hello{0}World", ch);
    }
}
