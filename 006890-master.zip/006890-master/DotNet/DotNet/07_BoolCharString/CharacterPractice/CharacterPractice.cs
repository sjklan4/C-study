﻿using System;

class CharacterPractice
{
    static void Main()
    {
        char ch = '\n';

        Console.WriteLine("Hello{0}World", ch);
    }
}
