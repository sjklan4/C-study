﻿using System;

class StringInterpolationDescription
{
    static void Main()
    {
        // 문자열 보간법(보간된 문자열)
        int number = 3;

        string result = "홀수";

        Console.WriteLine($"{number}은(는) {result}입니다.");
    }
}
